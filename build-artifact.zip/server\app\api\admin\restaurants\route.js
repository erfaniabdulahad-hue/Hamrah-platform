var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/restaurants/route.js")
R.c("server/chunks/[root-of-the-server]__04xlhys._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_admin_restaurants_route_actions_0xwajzd.js")
R.m(79933)
module.exports=R.m(79933).exports
