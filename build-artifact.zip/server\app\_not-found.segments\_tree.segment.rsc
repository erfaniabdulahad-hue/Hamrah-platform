:HL["/_next/static/chunks/1uuoc-remq9_d.css","style"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"/_not-found","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"9Nfq6chGe-DuNQ-Rii7Lc"}
