var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/payments/route.js")
R.c("server/chunks/[root-of-the-server]__0jrrukt._.js")
R.c("server/chunks/[root-of-the-server]__0l3yhx4._.js")
R.c("server/chunks/_next-internal_server_app_api_payments_route_actions_01zozoj.js")
R.m(82917)
module.exports=R.m(82917).exports
