module.exports=[43523,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_admin_restaurants_route_actions_0xwajzd.js.map