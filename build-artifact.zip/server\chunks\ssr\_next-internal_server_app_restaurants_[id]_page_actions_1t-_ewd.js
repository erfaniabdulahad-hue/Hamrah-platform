module.exports=[15328,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_restaurants_%5Bid%5D_page_actions_1t-_ewd.js.map